import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";

(() => {
  const figure = document.querySelector("#hologramHero .figure");
  if (!figure) return;

  figure.replaceChildren();
  figure.classList.add("eclipse-model");
  const host = document.createElement("div");
  host.id = "eclipseModelCanvas";
  host.setAttribute("role", "img");
  host.setAttribute("aria-label", "ECLIPSE 3D hologram");
  Object.assign(host.style, { position:"absolute", inset:"0", width:"100%", height:"100%", minHeight:"320px" });
  figure.append(host);
  Object.assign(figure.style, { width:"min(76%,560px)", height:"94%", maxHeight:"none", zIndex:"1" });

  const status = document.querySelector("#assistantMode");
  const hero = document.querySelector("#heroStatus");
  const setMode = (mode) => {
    // Hologram lifecycle is independent from the bot API connection indicator.
    if (status) status.textContent = mode;
  };
  let hologramLoaded = false;
  const showDiagnostic = (message) => {
    let note = host.querySelector("[data-hologram-diagnostic]");
    if (!note) {
      note = document.createElement("div");
      note.dataset.hologramDiagnostic = "true";
      note.setAttribute("role", "status");
      note.style.cssText = "position:absolute;left:8%;right:8%;bottom:8px;text-align:center;color:#ff9aa9;font-size:10px;line-height:1.5;z-index:3";
      host.append(note);
    }
    note.textContent = message;
  };


  // Procedural ECLIPSE reconstruction: independent geometry, no GLB dependency.
  const buildProceduralClone = () => {
    const root = new THREE.Group();
    const rig = new THREE.Group(); root.add(rig);
    const mat = (color, roughness=.45, metalness=.08, emissive=0x000000, intensity=0) => new THREE.MeshStandardMaterial({color,roughness,metalness,emissive,emissiveIntensity:intensity});
    const skin=mat(0xe8e7e7,.62,.02,0x182b34,.08), hair=mat(0x030508,.2,.16,0x07121a,.18), hairGlow=new THREE.MeshBasicMaterial({color:0x83eaff,transparent:true,opacity:.42});
    const shirt=mat(0xdce5e8,.72,.03,0x16313b,.12), black=mat(0x080a0f,.4,.12,0x07151d,.2), eye=mat(0xe6edf0,.3,.02,0x173744,.16), iris=mat(0x8495a1,.22,.22,0x1a5b70,.4), ink=mat(0x11151c,.65), cyan=mat(0x6deaff,.3,.35,0x17cfff,1.35);
    const add=(geo,material,parent,x,y,z,sx=1,sy=1,sz=1)=>{const m=new THREE.Mesh(geo,material);m.position.set(x,y,z);m.scale.set(sx,sy,sz);parent.add(m);return m;};
    const ball=(parent,material,x,y,z,sx,sy,sz)=>add(new THREE.SphereGeometry(1,32,20),material,parent,x,y,z,sx,sy,sz);
    const stroke=(parent,pts,r,material)=>{const c=new THREE.CatmullRomCurve3(pts.map(p=>new THREE.Vector3(...p)));const m=new THREE.Mesh(new THREE.TubeGeometry(c,32,r,8,false),material);parent.add(m);return m;};
    const shape=(parent,pts,material,z=.4,depth=.07)=>{const s=new THREE.Shape();s.moveTo(pts[0][0],pts[0][1]);pts.slice(1).forEach(p=>s.lineTo(p[0],p[1]));s.closePath();const m=new THREE.Mesh(new THREE.ExtrudeGeometry(s,{depth,bevelEnabled:true,bevelSegments:2,bevelSize:.018,bevelThickness:.018}),material);m.position.z=z;parent.add(m);return m;};

    // Upper-body silhouette and uniform: white shirt, black sleeveless vest, loose tie.
    ball(rig,shirt,0,-.94,0,.92,.78,.43);
    ball(rig,skin,0,-.02,.02,.27,.52,.27);
    shape(rig,[[-.78,-1.62],[-.9,-.82],[-.61,-.32],[-.33,-.48],[-.18,-1.58]],black,.34,.1);
    shape(rig,[[.78,-1.62],[.9,-.82],[.61,-.32],[.33,-.48],[.18,-1.58]],black,.34,.1);
    shape(rig,[[-.37,-.18],[-.12,-.42],[0,-.53],[.12,-.42],[.37,-.18],[.18,-.78],[0,-.91],[-.18,-.78]],shirt,.48,.08);
    shape(rig,[[-.38,-.18],[-.06,-.42],[-.19,-.75],[-.48,-.38]],shirt,.57,.08);
    shape(rig,[[.38,-.18],[.06,-.42],[.19,-.75],[.48,-.38]],shirt,.57,.08);
    ball(rig,black,0,-.48,.64,.13,.1,.07);
    shape(rig,[[-.105,-.55],[.105,-.55],[.15,-1.43],[0,-1.63],[-.15,-1.43]],black,.64,.06);

    // Face, jaw, ears and detailed eyes.
    ball(rig,skin,0,1.03,.06,.62,.83,.47);
    ball(rig,skin,-.61,.98,.03,.105,.19,.11); ball(rig,skin,.61,.98,.03,.105,.19,.11);
    for(const side of [-1,1]){
      const x=side*.265;
      ball(rig,eye,x,1.12,.505,.205,.09,.035);
      ball(rig,iris,x,1.12,.54,.067,.068,.022);
      ball(rig,ink,x,1.12,.559,.026,.052,.012);
      ball(rig,eye,x-.02,1.15,.573,.014,.014,.007);
      stroke(rig,[[x-.22,1.15,.53],[x-.1,1.23,.55],[x,1.25,.56],[x+.12,1.22,.55],[x+.22,1.14,.52]],.014,ink);
      stroke(rig,[[x-.19,1.34,.48],[x-.06,1.38,.51],[x+.08,1.37,.51],[x+.19,1.32,.48]],.022,hair);
      for(let i=0;i<4;i++)stroke(rig,[[x+side*(.13+i*.025),1.06,.52],[x+side*(.16+i*.03),1.015,.51]],.006,ink);
    }
    stroke(rig,[[0,1.08,.56],[-.025,.9,.59],[.015,.85,.58]],.009,ink);
    stroke(rig,[[-.16,.68,.53],[-.06,.65,.56],[.07,.65,.56],[.17,.69,.53]],.012,ink);
    // Thin angular face markings from the supplied reference.
    stroke(rig,[[-.53,1.0,.47],[-.27,.99,.55],[0,1.02,.59],[.28,1.01,.55],[.53,1.03,.47]],.008,cyan);
    stroke(rig,[[.34,1.01,.55],[.37,.82,.56],[.52,.66,.49]],.01,cyan);
    stroke(rig,[[.37,.82,.56],[.54,.84,.49]],.008,cyan);

    // Dense black hair cap and long curtain locks framing the face and torso.
    ball(rig,hair,0,1.82,-.12,.73,.58,.53);
    ball(rig,hair,0,1.38,-.25,.78,.77,.42);
    for(const side of [-1,1]){
      stroke(rig,[[side*.5,1.92,.1],[side*.72,1.36,.12],[side*.76,.45,.16],[side*.73,-.58,.22],[side*.62,-1.42,.27]],.17,hair);
      stroke(rig,[[side*.63,1.75,-.02],[side*.8,.96,-.02],[side*.83,.05,.04],[side*.76,-.8,.12]],.105,hair);
      stroke(rig,[[side*.4,1.72,.28],[side*.54,1.0,.31],[side*.52,.1,.34],[side*.46,-.5,.35]],.075,hair);
      stroke(rig,[[side*.68,1.72,.12],[side*.74,1.0,.19],[side*.72,.2,.23]],.006,hairGlow);
    }
    const bangs=[[[-.59,2.08,.38],[-.51,1.65,.55],[-.42,1.35,.58],[-.33,1.12,.55]],[[-.39,2.16,.44],[-.32,1.76,.59],[-.21,1.45,.62],[-.1,1.19,.59]],[[-.16,2.2,.46],[-.13,1.82,.62],[-.02,1.51,.64],[.08,1.24,.61]],[[.08,2.17,.45],[.13,1.82,.61],[.24,1.53,.63],[.34,1.29,.58]],[[.31,2.1,.42],[.39,1.73,.57],[.48,1.47,.57],[.54,1.3,.52]],[[.5,2.0,.37],[.59,1.65,.52],[.61,1.4,.5]]];
    bangs.forEach((p,i)=>stroke(rig,p,.105-(i%2)*.015,hair));
    for(let i=0;i<9;i++){const x=-.58+i*.145;stroke(rig,[[x,2.25,.35],[x*.92,1.98,.5],[x*.88,1.66,.56],[x*.84,1.39,.54]],.005,hairGlow);}
    stroke(rig,[[-.84,-.5,.3],[-.73,-.95,.4],[-.66,-1.5,.36]],.009,cyan);
    stroke(rig,[[.84,-.5,.3],[.73,-.95,.4],[.66,-1.5,.36]],.009,cyan);

    // Subtle shoulder and head movement is applied by the shared animation loop.
    const count=110,positions=new Float32Array(count*3);
    for(let i=0;i<count;i++){const a=i*2.399,r=1.0+(i%6)*.13;positions[i*3]=Math.cos(a)*r;positions[i*3+1]=-1.7+(i%14)*.27;positions[i*3+2]=Math.sin(a)*.38-.35;}
    const pg=new THREE.BufferGeometry();pg.setAttribute("position",new THREE.BufferAttribute(positions,3));
    const particles=new THREE.Points(pg,new THREE.PointsMaterial({color:0x71eaff,size:.012,transparent:true,opacity:.68}));root.add(particles);
    root.userData.rig=rig;root.userData.particles=particles;root.userData.baseY=0;
    return root;
  };

  let renderer;
  try {
    if (!window.WebGLRenderingContext) throw new Error("WebGL is not supported by this browser.");
    renderer = new THREE.WebGLRenderer({ alpha:true, antialias:true, powerPreference:"high-performance" });
  } catch (error) {
    console.error("[ECLIPSE] WebGL initialization failed", error);
    setMode("WEBGL UNAVAILABLE");
    showDiagnostic("3D projection unavailable in this browser. Enable WebGL or try a supported browser.");
    renderer = null;
  }

  if (renderer) {
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.25;
  renderer.setClearColor(0x000000, 0);
  Object.assign(renderer.domElement.style, { width:"100%", height:"100%", display:"block" });
  host.append(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
  camera.position.set(0, 0.55, 7.6);
  scene.add(new THREE.HemisphereLight(0xc5f6ff, 0x071321, 2.0));
  const key = new THREE.DirectionalLight(0x9beeff, 3.0); key.position.set(3,4,5); scene.add(key);
  const rim = new THREE.PointLight(0x548cff, 22, 12); rim.position.set(-3,1,1); scene.add(rim);
  const fill = new THREE.PointLight(0x8ffff0, 12, 10); fill.position.set(2,-1,3); scene.add(fill);

  const resize = () => {
    if (!renderer || !host.isConnected) return;
    const w = Math.max(1, host.clientWidth), h = Math.max(1, host.clientHeight);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  };
  const resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(host);
  window.addEventListener("resize", resize, { passive:true });
  resize();

  let targetRotationY = 0;
  let dragging = false, lastPointerX = 0;
  renderer.domElement.style.touchAction = "none";
  renderer.domElement.style.cursor = "grab";
  renderer.domElement.addEventListener("pointerdown", (event) => {
    dragging = true; lastPointerX = event.clientX;
    renderer.domElement.setPointerCapture(event.pointerId);
    renderer.domElement.style.cursor = "grabbing";
  });
  renderer.domElement.addEventListener("pointermove", (event) => {
    if (!dragging) return;
    targetRotationY += (event.clientX - lastPointerX) * .009;
    lastPointerX = event.clientX;
  });
  const endDrag = () => { dragging=false; renderer.domElement.style.cursor="grab"; };
  renderer.domElement.addEventListener("pointerup", endDrag);
  renderer.domElement.addEventListener("pointercancel", endDrag);
  renderer.domElement.addEventListener("wheel", (event) => {
    event.preventDefault();
    camera.position.z = THREE.MathUtils.clamp(camera.position.z + event.deltaY * .003, 6.0, 9.2);
  }, {passive:false});

  let model = buildProceduralClone();
  scene.add(model);
  hologramLoaded = true;
  setMode("PROCEDURAL 3D CLONE ONLINE");
  showDiagnostic("Procedural reconstruction active · original GLB retained as fallback asset");
  let frame = 0;
  let disposed = false;
  const clock = new THREE.Clock();
  const render = () => {
    if (disposed) return;
    frame = requestAnimationFrame(render);
    if (model && !renderer.getContext().isContextLost()) {
      const t = clock.getElapsedTime();
      model.rotation.y += (targetRotationY - model.rotation.y) * .045;
      model.position.y = model.userData.baseY + Math.sin(t * .8) * .025;
      if (model.userData.rig) {
        model.userData.rig.rotation.z = Math.sin(t * .75) * .018;
        model.userData.rig.rotation.x = Math.sin(t * .5) * .012;
        if (model.userData.particles) model.userData.particles.rotation.y = t * .12;
        model.userData.rig.children.forEach((part) => {
          if (part.userData.arm) part.rotation.z = part.userData.side * (0.035 + Math.sin(t * 1.1) * .025);
        });
      }
      renderer.render(scene, camera);
    }
  };
  render();

  renderer.domElement.addEventListener("webglcontextlost", (event) => {
    event.preventDefault();
    setMode("WEBGL CONTEXT LOST");
    showDiagnostic("Graphics context interrupted. Waiting for the browser to restore the 3D renderer…");
  });
  renderer.domElement.addEventListener("webglcontextrestored", () => {
    renderer.resetState();
    resize();
    setMode(model ? "3D CORE ONLINE" : "LOADING 3D CORE");
    if (model) showDiagnostic("");
  });

  // The original GLB remains untouched as a separately retained fallback asset.
  const manager = new THREE.LoadingManager();
  manager.onProgress = (_url, loaded, total) => {
    if (total > 0 && !model) setMode("LOADING MODEL " + Math.round(loaded / total * 100) + "%");
  };
  manager.onError = (url) => {
    console.error("[ECLIPSE] Asset request failed:", url);
    setMode("MODEL ASSET ERROR");
    showDiagnostic("A 3D asset could not be downloaded. Check the model request in the browser network panel.");
  };
  const loader = new GLTFLoader(manager);
  const modelTimeout = window.setTimeout(() => {
    if (!model && !disposed) {
      setMode("MODEL LOAD TIMEOUT");
      showDiagnostic("The hologram is taking too long to load. Check the GLB request and server response.");
    }
  }, 45000);

  // Original GLB remains available at /eclipse-hologram-enhanced-1.glb as a manual fallback.


  window.addEventListener("beforeunload", () => {
    disposed = true;
    window.clearTimeout(modelTimeout);
    cancelAnimationFrame(frame);
    resizeObserver.disconnect();
    window.removeEventListener("resize", resize);
    renderer.dispose();
  }, { once:true });
  }

  const log = document.querySelector("#chatlog");
  const input = document.querySelector("#assistantInput");
  const send = document.querySelector("#assistantSend");
  const feedback = document.querySelector("#assistantFeedback");
  const history = [];
  let busy = false;
  const bubble = (who, message, ai=false) => {
    if (!log) return;
    const node = document.createElement("div"); node.className = "bubble" + (ai ? " ai" : "");
    const label = document.createElement("div"); label.className = "who"; label.textContent = who;
    const body = document.createElement("div"); body.textContent = message;
    node.append(label, body); log.append(node); log.scrollTop = log.scrollHeight;
  };
  async function ask() {
    const message = (input?.value || "").trim();
    if (!message || busy) return;
    input.value = ""; busy = true; if (send) send.disabled = true;
    setMode("THINKING"); if (feedback) feedback.textContent = "ECLIPSE is consulting the configured AI model…";
    bubble("YOU", message);
    try {
      const response = await fetch("/api/ai/chat", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({ message, history:history.slice(-12) })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || "AI request failed.");
      const answer = String(data.reply || "").trim() || "I couldn't produce a response.";
      history.push({ role:"user", content:message }, { role:"assistant", content:answer });
      bubble("ECLIPSE / AI", answer, true);
      setMode(hologramLoaded ? "3D CORE ONLINE" : "AI ONLINE · MODEL PENDING");
      if (feedback) feedback.textContent = "Response generated by " + (data.model || "configured model") + ".";
    } catch (error) {
      bubble("ECLIPSE / SYSTEM", error.message, true);
      setMode("AI OFFLINE");
      if (feedback) feedback.textContent = error.message;
    } finally {
      busy = false;
      if (send) send.disabled = false;
    }
  }
  send?.addEventListener("click", (event) => { event.preventDefault(); event.stopImmediatePropagation(); ask(); }, true);
  input?.addEventListener("keydown", (event) => {
    if (event.key === "Enter") { event.preventDefault(); event.stopImmediatePropagation(); ask(); }
  }, true);

})();
